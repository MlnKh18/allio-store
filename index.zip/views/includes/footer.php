    <!-- Footer Section -->
    <footer>
        <p>&copy; 2025 Your Website. All rights reserved.</p>
    </footer>

    </body>

    </html>